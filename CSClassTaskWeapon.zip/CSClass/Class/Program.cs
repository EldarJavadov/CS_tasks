﻿using Class.Models;

Fire M16 = new Fire("M16",600, 15, 10);
M16.WeaponInfo();

M16.Single(100);

M16.Auto(50);
