﻿using System.Net.NetworkInformation;

namespace Class.Models;

internal class Fire : Weapon
{
    public Fire(
        string type,
        int bulletCapacity,
        int currentBulletCount,
        int consumptionInSecond) : base(type, bulletCapacity, currentBulletCount, consumptionInSecond)
    {
        Type = type;
        BulletCapacity = bulletCapacity;
        CurrentBulletCount = currentBulletCount;
        ConsumptionInSecond = consumptionInSecond;
    }


    public override void WeaponInfo()
    {
        base.WeaponInfo();
    }


    public void Single(int bulletCount)
    {
        if ( (bulletCount + CurrentBulletCount) <= BulletCapacity)
        {
            Console.WriteLine($"Bu silah elave {FireInBullet(bulletCount)} saniye ates aca bilcek");
        }
        else
        {
            Console.WriteLine($"Bu silah maksimum {BulletCapacity} patron tutur");
        }
    }


    public void Auto(int timeInSecond)
    {
        int howLongCanFire = BulletCapacity / ConsumptionInSecond;
        int withCurrentBulletHowLongCanFire = CurrentBulletCount / ConsumptionInSecond;
        int bulletCountForUse = timeInSecond * ConsumptionInSecond;

        if ( (timeInSecond + withCurrentBulletHowLongCanFire) > howLongCanFire)
        {
            Console.WriteLine($"Bu silah auto rejimde bir doldurmaya maksimum {BulletCapacity / ConsumptionInSecond} saniye ates aca biler");
        }
        else
        {
            Console.WriteLine($"Teyin olunan vaxt qeder elave ates acmaq ucun {bulletCountForUse} eded patron lazimdir");
        }
    }



    private int FireInBullet(int allBulletCount)
    {
        return (allBulletCount * 60) / BulletCapacity;
    }




}
