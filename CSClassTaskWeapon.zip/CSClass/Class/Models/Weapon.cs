﻿namespace Class.Models;

public class Weapon
{
    public string Type;
    public int BulletCapacity;
    public int CurrentBulletCount;
    public int ConsumptionInSecond;

    public Weapon(string type, int bulletCapacity, int currentBulletCount, int consumptionInSecond)
    {
        Type = type;
        BulletCapacity = bulletCapacity;
        CurrentBulletCount = currentBulletCount;
        ConsumptionInSecond = consumptionInSecond;
    }

    public virtual void WeaponInfo()
    {
        Console.WriteLine(
            $" Type: {Type} " +
            $"\n BulletCapacity: {BulletCapacity} " +
            $"\n CurrentBulletCount: {CurrentBulletCount} " +
            $"\n ConsumptionInSecond: {ConsumptionInSecond}");
    }
}
