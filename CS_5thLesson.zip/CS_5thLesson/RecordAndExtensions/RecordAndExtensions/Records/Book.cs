﻿namespace RecordAndExtensions.Records;

public record Book(string Title,string Author,int PublicationYear);




