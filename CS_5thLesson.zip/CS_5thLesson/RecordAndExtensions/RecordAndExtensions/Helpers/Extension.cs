﻿using RecordAndExtensions.Records; //-- asagidaki this Book-un goturulmesi ucun istifade olunur
using System.Runtime.CompilerServices;

namespace RecordAndExtensions.Helpers;

public static class Extension
{
    public static void DeconstructRecord(this Book kitab)
    {
        var (Title, Author, PublicationYear) = kitab;//-- bu proses deconstruction adlanir

        Console.WriteLine($" Title: {Title}\n Author: {Author}\n Publication year: {PublicationYear}");
    }
}
