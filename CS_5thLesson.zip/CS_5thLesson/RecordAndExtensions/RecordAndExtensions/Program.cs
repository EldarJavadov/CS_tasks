﻿using RecordAndExtensions.Helpers;
using RecordAndExtensions.Records;

Book book1 = new("Kitabin basligi", "Kitabin muellifi", 2023);
Book book2 = new("Basliq", "Muellif", 2023);

//Console.WriteLine(book2==book1);
//Console.WriteLine($" Title: {book.Title}\n Author: {book.Author}\n Publication year: {book.PublicationYear}");

book1.DeconstructRecord();