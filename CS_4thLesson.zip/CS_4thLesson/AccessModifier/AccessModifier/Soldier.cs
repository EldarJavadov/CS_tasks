﻿
public class Soldier
{
    public string Name;
    public string Surname;
    public int Age;
    public string Rank;
    public int YearOfService;
    public bool IsCurrentlyWorking;


    public Soldier(string name, string surname, int age, string rank, int yearOfService, bool isCurrentlyWorking) 
    {
               
    }


    public virtual string PerformDuty(string mission)
    {
        if (CheckSoldierStatus())
        {

        }
        return "strinr";
    }


    private bool CheckSoldierStatus()
    {
        if (YearOfService < 3)
        {
            Console.WriteLine("Esgerin is tecribesi minimum 3 il olmalidir.");
            return false;
        }
        else
        {
            return true;
        }
    }
}