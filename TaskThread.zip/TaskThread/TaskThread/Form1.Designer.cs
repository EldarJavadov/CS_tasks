﻿namespace TaskThread
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            dataGridView1 = new DataGridView();
            ss = new DataGridViewTextBoxColumn();
            id = new DataGridViewTextBoxColumn();
            userId = new DataGridViewTextBoxColumn();
            title = new DataGridViewTextBoxColumn();
            body = new DataGridViewTextBoxColumn();
            progressBar1 = new ProgressBar();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 10F);
            button1.Location = new Point(547, 26);
            button1.Name = "button1";
            button1.Size = new Size(104, 37);
            button1.TabIndex = 0;
            button1.Text = "Show all data";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_ClickAsync;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 10F);
            button2.Location = new Point(376, 26);
            button2.Name = "button2";
            button2.Size = new Size(134, 37);
            button2.TabIndex = 1;
            button2.Text = "Show selected data";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 10F);
            button3.Location = new Point(684, 26);
            button3.Name = "button3";
            button3.Size = new Size(104, 37);
            button3.TabIndex = 2;
            button3.Text = "Export to .txt";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { ss, id, userId, title, body });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.Location = new Point(12, 83);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.Size = new Size(776, 355);
            dataGridView1.TabIndex = 3;
            // 
            // ss
            // 
            ss.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            ss.FillWeight = 50.76142F;
            ss.HeaderText = "S/s";
            ss.Name = "ss";
            ss.Width = 48;
            // 
            // id
            // 
            id.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            id.FillWeight = 144.72113F;
            id.HeaderText = "Id";
            id.Name = "id";
            id.Width = 42;
            // 
            // userId
            // 
            userId.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            userId.FillWeight = 163.193283F;
            userId.HeaderText = "Istifadeci id";
            userId.Name = "userId";
            userId.Width = 92;
            // 
            // title
            // 
            title.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            title.FillWeight = 70.662056F;
            title.HeaderText = "Basliq";
            title.Name = "title";
            // 
            // body
            // 
            body.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            body.FillWeight = 70.662056F;
            body.HeaderText = "Metn";
            body.Name = "body";
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(12, 428);
            progressBar1.Margin = new Padding(3, 3, 3, 0);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(776, 10);
            progressBar1.Step = 1;
            progressBar1.TabIndex = 4;
            progressBar1.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(progressBar1);
            Controls.Add(dataGridView1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Thread, File task";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private DataGridView dataGridView1;
        private ProgressBar progressBar1;
        private DataGridViewTextBoxColumn ss;
        private DataGridViewTextBoxColumn id;
        private DataGridViewTextBoxColumn userId;
        private DataGridViewTextBoxColumn title;
        private DataGridViewTextBoxColumn body;
    }
}
