﻿
using Newtonsoft.Json;
using System.Text;
using System.Windows.Forms;

namespace TaskThread
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        #region Show all data
        private async void button1_ClickAsync(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            progressBar1.Visible = true;
            int counter = 0;
            string path = "https://jsonplaceholder.typicode.com/posts";


            IProgress<int> progress = new Progress<int>(value =>
            {
                progressBar1.Value = value;
            });


            try
            {
                List<Post> dataList = await getPostDatasAsync(path, progress);
                dataGridView1.Rows.Clear();

                foreach (var data in dataList)
                {
                    counter++;
                    int rowIndex = dataGridView1.Rows.Add();

                    dataGridView1["ss", rowIndex].Value = counter;
                    dataGridView1["id", rowIndex].Value = data.id;
                    dataGridView1["userId", rowIndex].Value = data.userId;
                    dataGridView1["title", rowIndex].Value = data.title;
                    dataGridView1["body", rowIndex].Value = data.body;
                }

                MessageBox.Show("Məlumat uğurla əldə edildi", "Bildiriş");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error");
            }
            finally
            {
                progressBar1.Visible = false;
            }
        }

        async Task<List<Post>> getPostDatasAsync(string path, IProgress<int> progress)
        {
            HttpClient client = new HttpClient();
            string result = await client.GetStringAsync(path);
            List<Post>? dataList = JsonConvert.DeserializeObject<List<Post>>(result);

            progress?.Report(100);

            return dataList;
        }
        #endregion

        #region Show selected data
        private async void button2_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            progressBar1.Visible = true;
            int counter = 0;
            List<int> selectedIds = new List<int> { 1, 10, 100 };

            IProgress<int> progress = new Progress<int>(value =>
            {
                progressBar1.Value = value;
            });

            try
            {
                List<Post> dataList = await getSelectedPostDatasAsync(selectedIds, progress);
                dataGridView1.Rows.Clear();

                foreach (var data in dataList)
                {
                    counter++;
                    int rowIndex = dataGridView1.Rows.Add(counter, data.id, data.userId, data.title, data.body);
                }

                MessageBox.Show("Seçilmiş məlumat uğurla əldə edildi", "Bildiriş");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error");
            }
            finally
            {
                progressBar1.Visible = false;
            }
        }

        async Task<List<Post>> getSelectedPostDatasAsync(List<int> selectedIds, IProgress<int> progress)
        {
            List<Post> dataList = new List<Post>();
            HttpClient client = new HttpClient();

            foreach (int id in selectedIds)
            {
                string path = $"https://jsonplaceholder.typicode.com/posts/{id}";
                string result = await client.GetStringAsync(path);
                Post post = JsonConvert.DeserializeObject<Post>(result);

                dataList.Add(post);

                progress?.Report((selectedIds.IndexOf(id) + 1) * 100 / selectedIds.Count);
            }

            progress?.Report(100);

            return dataList;
        }
    
        #endregion

        #region Export data to .txt file
        private void button3_Click(object sender, EventArgs e)
        {

            if (dataGridView1.Rows.Count > 1)
            {
                StringBuilder sb = new StringBuilder();

                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    string title = row.Cells["title"].Value.ToString().Replace("\n", " ");
                    string body = row.Cells["body"].Value.ToString().Replace("\n", " ");

                    sb.AppendLine(
                        $"id: {row.Cells["id"].Value}, \n" +
                        $"userId: {row.Cells["userId"].Value}, \n" +
                        $"title: {title}, \n" +
                        $"body: {body}\n\n");
                }

                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

                string filePath = Path.Combine(desktopPath, "Datas.txt");

                File.WriteAllText("Datas.txt", sb.ToString());

                MessageBox.Show("Məlumat uğurla Datas.txt faylına yazıldı", "Məlumat");
            }
            else
            {
                MessageBox.Show("Cədvəldə məlumat tapılmadı.", "Məlumat");
            }


        }
        #endregion

        #region General
        public class Post
        {
            public int id { get; set; }
            public int userId { get; set; }
            public string title { get; set; }
            public string body { get; set; }
        }
        #endregion
    }
}