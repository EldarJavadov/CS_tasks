﻿namespace AccessModifier.Modelds;

public class InfantrySoldier : Soldier
{
	public string PrimaryWeapon;

    public InfantrySoldier(
        string name, 
        string surname, 
        int age, 
        string rank, 
        int yearOfService, 
        bool isCurrentlyWorking, 
        string primaryWeapon) : base(name, surname, age, rank, yearOfService, isCurrentlyWorking)
    {
        PrimaryWeapon = primaryWeapon;
    }

    public override void PerformDuty(string mission)
    {
        Console.WriteLine(mission);
    }

}



public class MedicSolider : Soldier
{
    public string MedicSpeciality;

    public MedicSolider(
        string name,
        string surname,
        int age,
        string rank,
        int yearOfService,
        bool isCurrentlyWorking,
        string medicSpeciality) : base(name, surname, age, rank, yearOfService, isCurrentlyWorking)
    {
        MedicSpeciality = medicSpeciality;
    }

    public override void PerformDuty(string mission)
    {
        Console.WriteLine(mission);
    }
}



public class DeveloperEngineerSolider : Soldier
{
    public string EngineerSpeciality;

    public DeveloperEngineerSolider(
        string name,
        string surname,
        int age,
        string rank,
        int yearOfService,
        bool isCurrentlyWorking,
        string engineerSpeciality) : base(name, surname, age, rank, yearOfService, isCurrentlyWorking)
    {
        EngineerSpeciality = engineerSpeciality;
    }

    public override void PerformDuty(string mission)
    {
        Console.WriteLine(mission);
    }
}
