﻿using System.Runtime.CompilerServices;

namespace AccessModifier.Modelds;

public class Soldier
{
    public string Name;
    public string Surname;
    public int Age;
    public string Rank;
    public int YearOfService;
    public bool IsCurrentlyWorking;

    public Soldier(string name, string surname, int age, string rank, int yearOfService, bool isCurrentlyWorking)
    {
        Name = name;
        Surname = surname;
        Age = age;
        Rank = rank;
        YearOfService = yearOfService;
        IsCurrentlyWorking = isCurrentlyWorking;
    }


    public string CurrentlyWorkingStatus = "Xidmet etmir.";
    public virtual void PerformDuty(string mission)
    {
        if (IsCurrentlyWorking)
        {
            CurrentlyWorkingStatus = "Xidmet edir.";
        }

        if (CheckSoldierStatus())
        {
            Console.WriteLine(
                $"Ad: {Name} " +
                $"\nSoyad: {Surname} " +
                $"\nYas: {Age}" +
                $"\nRutbesi: {Rank}" +
                $"\nXidmet ili: {YearOfService}" +
                $"\nCari vaxtda statusu: {CurrentlyWorkingStatus}" +
                $"\nTapsiriq: {mission}");
        }
        else
        {
            Console.WriteLine("Esgerin is tecribesi minimum 3 il olmalidir.");
        }
        
    }


    private bool CheckSoldierStatus()
    {
        if (YearOfService < 3)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
}