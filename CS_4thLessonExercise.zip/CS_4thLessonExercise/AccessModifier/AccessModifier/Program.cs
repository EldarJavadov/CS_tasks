﻿using AccessModifier.Modelds;


InfantrySoldier soldier1  = new InfantrySoldier("Eldar", "Javadov", 22, "kapitan", 2, true, "Silah");
//soldier1.PerformDuty("Ates acir");
MedicSolider soldier2 = new MedicSolider("Eldar", "Javadov", 22, "kapitan", 2, true, "Cerrah");
//soldier2.PerformDuty("Emeliyyta edir");
DeveloperEngineerSolider soldier3 = new DeveloperEngineerSolider("Eldar", "Javadov", 22, "kapitan", 2, true, "Developer");
//soldier3.PerformDuty("Sistem qurur");